import os, csv, sys

#players.csv columns
PLAYER_COLS = 5
PLAYER_INDEX = 0
PLAYER_FIRST = 1
PLAYER_LAST = 2
PLAYER_SCHOOL = 3
PLAYER_RANK = 4

#round.csv columns
MATCH_COLS = 6
MATCH_FIRST = 0
MATCH_LAST = 1
MATCH_INDEX = 2
MATCH_SCHOOL = 3
MATCH_COLOR = 4
MATCH_RESULT = 5

#Make sure there is a parameter on the commandline
if len(sys.argv) < 2:
    print "Need the directory of the tournament:\n"
    print "\t python run_tournament.py [path to tournament files]\n"
    sys.exit()

tourn_path = sys.argv[1]

#make sure the path to the tournament directory is valid
if not os.path.exists(tourn_path):
    print "\nTournament path:\n\t", tourn_path, "\ndoes not exist\n"
    print "Please find valid path\n"
    sys.exit()

files = os.listdir(tourn_path)

#make sure the players.csv files exists
player_file = "players.csv"
if player_file not in files: 
    print "Cannot find:\n\t" + player_file + "\nfiles.\n"
    print "Please put " + player_file + " in the tournament directory"
    sys.exit()

#load the player information
players = [{}]
schools = {}

with open(os.path.join(tourn_path, player_file)) as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        if len(row) < 2: continue
        if (row[0][0] == '#'): continue
        if len(row) != PLAYER_COLS:
            print "\nInvalid Player: ", row, "\n"
            res = raw_input("Would you like to exit to fix input file? (y/n)")
            if res.lower().lstrip().rstrip() == 'y':
                sys.exit()
            continue
        player_idx = -1
        try: 
            player_idx = int(row[PLAYER_INDEX])
        except:
            print "\nNot a valid player index: ", row[PLAYER_INDEX], "\n"
            res = raw_input("Would you like to exit to fix input file? (y/n)")
            if res.lower().lstrip().rstrip() == 'y':
                sys.exit()
            continue
        rank = 500
        try: 
            if row[PLAYER_RANK].strip() != '':
                rank = int(row[PLAYER_RANK])
        except:
            print "\nNot a valid player rank: ", row[PLAYER_RANK], "\n"
            res = raw_input("Would you like to exit to fix input file? (y/n)")
            if res.lower().lstrip().rstrip() == 'y':
                sys.exit()
            continue
        players.insert(player_idx, {
            'idx': row[PLAYER_INDEX].lower().lstrip().rstrip(),
            'first': row[PLAYER_FIRST].lower().lstrip().rstrip(),
            'last': row[PLAYER_LAST].lower().lstrip().rstrip(),
            'school': row[PLAYER_SCHOOL].lower().lstrip().rstrip(),
            'rank': rank,
            'matches': []
        })
        if players[-1]['school'] not in schools.keys():
            schools[players[-1]['school']] = []
        schools[players[-1]['school']].append(players[-1])

#on the first time parsing the file, check and make sure things look correct
roundcnt = -1
if len(files) == 1:
    print "\nThe Schools in the tournament are:"
    for ss in schools.keys():
        print "\t", ss

    res = raw_input("There are " + str(len(schools.keys())) +
        " schools in the tournament, is this correct? (y/n)"
    )
    if res.lower().lstrip().rstrip() != 'n':
        print "Please fix ", player_file
        sys.exit()
     
    print "\n"
    res = raw_input("There are " + str(len(players)) + " players in the tournament, is this correct? (y/n)")
    if res.lower().lstrip().rstrip() != 'n':
        print "Please fix ", filename
        sys.exit()

    print "\n"
    while True:
        roundtmp = raw_input("How many rounds will be played today?")
        try:
            roundcnt = int(roundtmp)
        except:
            print "Invalid number: " + roundtmp + "\n\n"

#check and see if any rounds have been played
last_round = 0
for ff in files:
    if ff[0] == '.': continue
    if 'round' in ff:
        cur_round = -1
        try:
            idx = ff.find(".csv")
            cur_round = int(ff[5:idx])
            if cur_round > last_round:
                last_round = cur_round 
        except:
            print "\nInvalid round file, skipping " + ff + "\n"
            continue
        #parse the round file
        with open(os.path.join(tourn_path, ff)) as csvfile:
            reader = csv.reader(csvfile)
            matchnum = -1
            match1 = None
            match2 = None
            for row in reader:
                if len(row) == 0: continue
                if row[0][0] == '#': continue
                if 'TOTAL_ROUNDS' in row[0]:
                    try:
                        roundcnt = int(row[0][12:].lstrip().rstrip())
                    except:
                        print "Invalid round count: " + str(row[0][12:]) + "\n\n"
                        sys.exit()
                if "match" in row[0]:
                    try: 
                        matchnum = int(row[0][6:])
                    except:
                        print "Invalid match num: ", row[7:]
                    continue
                if matchnum == -1: continue
                try:
                    idx = int(row[MATCH_INDEX])
                    assert(idx < len(players))
                except:
                    print "Invalid match player index: ", row[MATCH_INDEX]
                if match1 == None:
                    match1 = {
                        'round':cur_round,
                        'match':matchnum,
                        'player':int(row[MATCH_INDEX].lower().lstrip().rstrip()),
                        'opponent':-1,
                        'color':row[MATCH_COLOR].lower().lstrip().rstrip(),
                        'result':row[MATCH_RESULT].lower().lstrip().rstrip()
                    }
                    if players[match1['player']]['first'] != row[MATCH_FIRST].lower().lstrip().rstrip():
                        print ("first names dont match: ",
                            players[match1['player']]['first'],
                            row[MATCH_FIRST].lower().lstrip().rstrip()
                        )
                        break
                    if players[match1['player']]['last'] != row[MATCH_LAST].lower().lstrip().rstrip():
                        print ("last names dont match: ",
                            players[match1['player']]['last'],
                            row[MATCH_LAST].lower().lstrip().rstrip()
                        )
                        break
                    continue
                if match2 == None:
                    match2 = {
                        'round':cur_round,
                        'match':matchnum,
                        'player':int(row[MATCH_INDEX].lower().lstrip().rstrip()),
                        'opponent':-1,
                        'color':row[MATCH_COLOR].lower().lstrip().rstrip(),
                        'result':row[MATCH_RESULT].lower().lstrip().rstrip()
                    }
                    if players[match2['player']]['first'] != row[MATCH_FIRST].lower().lstrip().rstrip():
                        print ("first names dont match: ",
                            players[match2['player']]['first'],
                            row[MATCH_FIRST].lower().lstrip().rstrip()
                        )
                        break
                    if players[match2['player']]['last'] != row[MATCH_LAST].lower().lstrip().rstrip():
                        print ("last names dont match: ",
                            players[match2['player']]['last'],
                            row[MATCH_LAST].lower().lstrip().rstrip()
                        )
                        break
                if match1 != None and match2 != None:
                    match1['opponent'] = match2['player']
                    match2['opponent'] = match1['player']
                    players[match1['player']]['matches'].append(match1)
                    players[match2['player']]['matches'].append(match2)
                else:
                    print "Invalid match file, exiting"
                    sys.exit()

#generate the next round of matches
print schools
matches = []
while True:

    break

#test output
matches = [{
    'index1':1,
    'index2':5,
    'color1':'white',
    'color2':'black'
}]
#dump to file
cur_round = last_round + 1
roundfile = os.path.join(tourn_path, "round" + str(cur_round) + ".csv") 
print roundfile
with open(roundfile, 'w') as mfile:
    mfile.write("#match MATCH_NUM\n")
    mfile.write("#PLAYER_FIRST, PLAYER_LAST, PLAYER_INDEX, ")
    mfile.write("PLAYER_SCHOOL, MATCH_COLOR(black,white), WIN_LOSS(win,loss)\n")
    mfile.write("TOTAL_ROUNDS " + str(roundcnt) + "\n\n")
    matchcnt = 1
    for mm in matches:
        mfile.write("match " + str(matchcnt) + "\n")
        mfile.write(",".join([
            players[mm['index1']]['first'],
            players[mm['index1']]['last'],
            str(mm['index1']),
            players[mm['index1']]['school'],
            mm['color1']
        ]) + ',\n')
        mfile.write(",".join([
            players[mm['index2']]['first'],
            players[mm['index2']]['last'],
            str(mm['index2']),
            players[mm['index2']]['school'],
            mm['color2']
        ]) + ',\n\n')
        matchcnt += 1

